package com.example.flomi

data class Product(
    val img: Int,
    val company: String,
    val name: String,
    val efficacy1: String,
    val efficacy2: String,
    val efficacy3: String
)
